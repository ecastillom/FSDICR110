function Car(Condition, Make, Model, Year, Color, Seats, Mileage, MPG, Image, Price){
    this.Condition = Condition;
    this.Make = Make;
    this.Model = Model;
    this.Year = Year;
    this.Color = Color;
    this.Seats = Seats;
    this.Mileage = Mileage;
    this.MPG = MPG;
    this.Image = Image;
    this.Price = Price;
}

function registerCar(){
    console.log("btnLog");

    var ddlCondition = $("#ddlCondition").val();
    var txtMake = $("#txtMake").val();
    var txtModel = $("#txtModel").val();
    var txtYear = $("#txtYear").val();
    var txtColor = $("#txtColor").val();
    var txtSeats = $("#txtSeats").val();
    var txtMileage = $("#txtMileage").val();
    var txtMPG = $("#txtMPG").val();
    var txtImage = $("#txtImage").val();
    var txtPrice = $("#txtPrice").val();

    var PriceAux = 0;

    if(txtPrice){
        PriceAux = parseFloat(txtPrice);
    }

    var YearAux = 0;

    if(txtYear){
        YearAux = parseInt(txtYear);
    }

    var SeatsAux = 0;

    if(txtSeats){
        SeatsAux = parseInt(txtSeats);
    }

    var MileagesAux = 0;

    if(txtMileage){
        MileagesAux = parseInt(txtMileage);
    }

    var MPGAux = 0;

    if(txtMPG){
        MPGAux = parseInt(txtMPG);
    }

    var car = new Car(ddlCondition, txtMake, txtModel, YearAux, txtColor, SeatsAux, MileagesAux, MPGAux, txtImage, PriceAux);

    console.log(car);

    $.ajax({
        url:'/Catalog/SaveCar',
        type:'POST',
        contentType: 'application/json',
        data: JSON.stringify(car),
        success: function(res){
            console.log("Server Responded", res);
            ClsForm();
        },
        error: function(detail){
            console.log("Error on Request", detail)
        }
    })
}

function ClsForm(){
    $("#ddlCondition").val('0');
    $("#txtMake").val('');
    $("#txtModel").val('');
    $("#txtYear").val('');
    $("#txtColor").val('');
    $("#txtSeats").val('');
    $("#txtMileage").val('');
    $("#txtMPG").val('');
    $("#txtImage").val('');
    $("#txtPrice").val('');
}

function init(){
    console.log("Register page");

    $("#btnSave").click(registerCar);
}

window.onload = init;