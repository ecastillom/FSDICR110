function retrieveCatalog(){
    $.ajax({
        url:'/catalog/getCatalog',
        type:'GET',
        success: function(res){
            console.log("Server Responded", res);

            for(let i=0; i < res.length; i++){
                displayCar(res[i])
            }
        },
        error: function(detail){
            console.log("Error on Request", detail)
        }
    })
}

function displayCar(car){
    var container = $("#row");

    var sntx = `
                    <div class="col-sm-6">
                        <div class="card">
                            <img src="${car.image}" class="card-img-top">
                            <div class="card-body">
                                <h5 class="card-title">${car.year} - ${car.make} ${car.model} ( Condition: ${car.condition} ) </h5>
                                <h5>
                                    $${car.price} dlls
                                </h5>
                                <p class="card-text">
                                    Color: ${car.color} | Seats: ${car.seats}  | Mileage: ${car.mileage}  | MPG: ${car.mpg} 
                                </p>
                            </div>
                        </div>
                    </div>`;

    container.append(sntx);
}

function init(){
    console.log("Catalog Page!");

    //get data
    retrieveCatalog();
    
    console.log("test");
    // hooks Events
}

window.onload = init;